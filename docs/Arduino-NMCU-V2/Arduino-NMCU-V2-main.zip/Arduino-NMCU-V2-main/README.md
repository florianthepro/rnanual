```
#include <Wire.h>
#include "rgb_lcd.h"

rgb_lcd lcd;

// Pin-Definitionen
const int BUTTON_JUMP = D8;  // Knopf zum Springen
const int BUTTON_DUCK = D7;  // Knopf zum Ducken

// Spielzustände
enum GameState {
  MENU,
  PLAYING,
  GAME_OVER
};

// Spielvariablen
GameState gameState = MENU;
int score = 0;
int highScore = 0;
unsigned long gameSpeed = 150;  // Millisekunden zwischen Bewegungen
unsigned long lastMoveTime = 0;

// Spieler-Eigenschaften
int playerRow = 1;  // Position auf LCD (0 oder 1)
int playerCol = 0;
bool isJumping = false;
int jumpHeight = 0;
int maxJumpHeight = 1;

// Gegner/Hindernis-Eigenschaften
struct Obstacle {
  int col;
  int row;
  bool active;
};

Obstacle obstacle = {16, 1, false};

// Custom Zeichen für das Spiel
byte playerChar[8] = {
  0b01100,
  0b10010,
  0b10010,
  0b01100,
  0b00100,
  0b01010,
  0b10001,
  0b00000
};

byte obstacleChar[8] = {
  0b11111,
  0b10001,
  0b10101,
  0b10001,
  0b11111,
  0b00000,
  0b00000,
  0b00000
};

byte jumpChar[8] = {
  0b00100,
  0b01010,
  0b10001,
  0b00000,
  0b00000,
  0b00000,
  0b00000,
  0b00000
};

void setup() {
  Serial.begin(9600);
  pinMode(BUTTON_JUMP, INPUT);
  pinMode(BUTTON_DUCK, INPUT);
  
  // LCD initialisieren (16x2 Display)
  lcd.begin(16, 2);
  
  // Custom Zeichen definieren
  lcd.createChar(0, playerChar);
  lcd.createChar(1, obstacleChar);
  lcd.createChar(2, jumpChar);
  
  // Startbildschirm
  lcd.setRGB(0, 255, 0);  // Grünes Licht
  drawMenu();
}

void loop() {
  switch(gameState) {
    case MENU:
      handleMenu();
      break;
    case PLAYING:
      handleGame();
      break;
    case GAME_OVER:
      handleGameOver();
      break;
  }
}

void drawMenu() {
  lcd.clear();
  lcd.setCursor(0, 0);
  lcd.print("DINO RUNNER");
  lcd.setCursor(0, 1);
  lcd.print("Press Jump to Start");
  delay(200);
}

void handleMenu() {
  if (digitalRead(BUTTON_JUMP)) {
    gameState = PLAYING;
    startGame();
    delay(500);  // Debounce
  }
}

void startGame() {
  score = 0;
  gameSpeed = 150;
  playerRow = 1;
  isJumping = false;
  jumpHeight = 0;
  obstacle.active = false;
  obstacle.col = 16;
  
  lcd.clear();
  lcd.setRGB(255, 255, 0);  // Gelbes Licht für Spielstart
}

void handleGame() {
  unsigned long currentTime = millis();
  
  // Knopfabfrage
  if (digitalRead(BUTTON_JUMP)) {
    if (!isJumping) {
      isJumping = true;
      jumpHeight = 0;
    }
    delay(200);  // Debounce
  }
  
  if (digitalRead(BUTTON_DUCK)) {
    playerRow = 1;  // Spieler duckt sich nach unten
    delay(200);  // Debounce
  } else if (!isJumping) {
    playerRow = 1;  // Standardposition
  }
  
  // Sprung-Logik
  if (isJumping) {
    jumpHeight++;
    if (jumpHeight > maxJumpHeight) {
      isJumping = false;
      jumpHeight = 0;
      playerRow = 1;
    } else {
      playerRow = 0;  // Spieler springt nach oben
    }
  }
  
  // Spiellogik mit Timing
  if (currentTime - lastMoveTime > gameSpeed) {
    lastMoveTime = currentTime;
    
    // Hindernis bewegen
    if (!obstacle.active) {
      obstacle.col = 16;
      obstacle.row = 1;
      obstacle.active = true;
    } else {
      obstacle.col--;
      if (obstacle.col < 0) {
        obstacle.active = false;
        score += 10;
        // Schwierigkeit erhöhen
        if (gameSpeed > 50) {
          gameSpeed -= 2;
        }
      }
    }
    
    // Kollisionserkennung
    if (obstacle.active && obstacle.col == playerCol && obstacle.row == playerRow) {
      gameState = GAME_OVER;
      if (score > highScore) {
        highScore = score;
      }
      return;
    }
    
    // Bildschirm zeichnen
    drawGame();
  }
}

void drawGame() {
  lcd.clear();
  
  // Obere Zeile - Hintergrund mit Hindernis
  lcd.setCursor(0, 0);
  for (int i = 0; i < 16; i++) {
    if (obstacle.active && obstacle.col == i && obstacle.row == 0) {
      lcd.write(1);  // Hindernis-Zeichen
    } else {
      lcd.print(" ");
    }
  }
  
  // Untere Zeile - Spieler und Hindernis
  lcd.setCursor(0, 1);
  for (int i = 0; i < 16; i++) {
    if (i == playerCol) {
      if (isJumping && jumpHeight > 0) {
        lcd.write(2);  // Sprung-Zeichen
      } else {
        lcd.write(0);  // Spieler-Zeichen
      }
    } else if (obstacle.active && obstacle.col == i && obstacle.row == 1) {
      lcd.write(1);  // Hindernis-Zeichen
    } else {
      lcd.print(" ");
    }
  }
  
  // Score anzeigen
  lcd.setCursor(0, 0);
  lcd.print("S:");
  lcd.print(score / 10);
}

void handleGameOver() {
  lcd.clear();
  lcd.setRGB(255, 0, 0);  // Rotes Licht für Game Over
  
  lcd.setCursor(0, 0);
  lcd.print("GAME OVER!");
  
  lcd.setCursor(0, 1);
  lcd.print("Score: ");
  lcd.print(score / 10);
  
  delay(2000);
  
  lcd.clear();
  lcd.setCursor(0, 0);
  lcd.print("High: ");
  lcd.print(highScore / 10);
  
  lcd.setCursor(0, 1);
  lcd.print("Press Jump Menu");
  
  if (digitalRead(BUTTON_JUMP)) {
    gameState = MENU;
    drawMenu();
    delay(500);  // Debounce
  }
}
```
