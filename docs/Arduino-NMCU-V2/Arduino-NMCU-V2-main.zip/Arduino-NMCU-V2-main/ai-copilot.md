```
#include <Wire.h>
#include "rgb_lcd.h"

rgb_lcd lcd;

const int BTN_JUMP = D8;   // Sprungtaste
const int BTN_START = D7;  // Starttaste

bool playing = false;
int dinoRow = 1;           // Dino sitzt unten (Zeile 1)
int obstaclePos = 15;      // Hindernis startet rechts
unsigned long lastUpdate = 0;
const int speed = 300;     // Geschwindigkeit des Spiels (ms)

void setup() {
  Serial.begin(9600);
  pinMode(BTN_JUMP, INPUT);
  pinMode(BTN_START, INPUT);

  lcd.begin(16, 2);
  lcd.setRGB(0, 255, 0);   // grünes Backlight
  lcd.clear();
  lcd.setCursor(0,0);
  lcd.print("Press START!");
}

void loop() {
  if (!playing) {
    if (digitalRead(BTN_START)) {
      playing = true;
      obstaclePos = 15;
      dinoRow = 1;
      lcd.clear();
    }
    return;
  }

  // Dino springt, wenn Taste gedrückt
  if (digitalRead(BTN_JUMP)) {
    dinoRow = 0; // oben
  } else {
    dinoRow = 1; // unten
  }

  // Spielupdate alle "speed" ms
  if (millis() - lastUpdate > speed) {
    lastUpdate = millis();
    obstaclePos--;

    lcd.clear();

    // Dino zeichnen
    lcd.setCursor(0, dinoRow);
    lcd.print("D"); // Dino

    // Hindernis zeichnen
    if (obstaclePos >= 0) {
      lcd.setCursor(obstaclePos, 1); // Hindernis immer unten
      lcd.print("|");
    } else {
      obstaclePos = 15; // neues Hindernis
    }

    // Kollision prüfen
    if (obstaclePos == 0 && dinoRow == 1) {
      lcd.clear();
      lcd.setCursor(0,0);
      lcd.print("GAME OVER!");
      lcd.setCursor(0,1);
      lcd.print("Press START");
      playing = false;
    }
  }
}

```
